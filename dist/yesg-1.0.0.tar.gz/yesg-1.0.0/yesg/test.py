import main as yesg

print(yesg.get_esg_full('BA').to_string())
print(yesg.get_esg_short('BA').to_string())